//
//  DeliverySession.swift
//  CoffeeCraft
//
//  Map Module — Phase 4 (Delivery)
//  Encapsulates the full state of one active delivery.
//  Written to Firestore at deliveries/{orderId} and synced in real-time
//  by DeliveryViewModel's snapshot listener.
//
//  CLLocationCoordinate2D is not Codable by default — we use a flat
//  lat/lng storage pattern to keep Firestore writes simple.
//

import CoreLocation
import Foundation

// MARK: - DeliverySession

struct DeliverySession {

    // MARK: - Identity

    let orderId: String
    let branchId: String

    // MARK: - Coordinates (flat storage, Codable-friendly)

    let branchLatitude:  Double
    let branchLongitude: Double

    /// The delivery destination — from SavedLocation or live GPS at order time.
    /// Stored once at order placement so simulation is stable even if the
    /// user's device moves.
    let destinationLatitude:  Double
    let destinationLongitude: Double

    /// Current rider position — updated every ~2 s by the simulator and by
    /// Firestore when a real rider GPS feed is available (Phase 6).
    var riderLatitude:  Double
    var riderLongitude: Double

    // MARK: - Status & Timing

    var status: DeliveryStatus
    var estimatedArrival: Date?

    // MARK: - Rider Info (optional — nil until riderAssigned)

    var riderName:  String?
    var riderPhone: String?

    // MARK: - Computed Coordinates

    var branchCoordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: branchLatitude, longitude: branchLongitude)
    }

    var destinationCoordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: destinationLatitude, longitude: destinationLongitude)
    }

    var riderCoordinate: CLLocationCoordinate2D {
        get { CLLocationCoordinate2D(latitude: riderLatitude, longitude: riderLongitude) }
        set {
            riderLatitude  = newValue.latitude
            riderLongitude = newValue.longitude
        }
    }

    // MARK: - Firestore Document Mapping

    /// Creates a Firestore-writable dictionary for deliveries/{orderId}.
    func asFirestoreData() -> [String: Any] {
        var data: [String: Any] = [
            "orderId":              orderId,
            "branchId":             branchId,
            "branchLatitude":       branchLatitude,
            "branchLongitude":      branchLongitude,
            "destinationLatitude":  destinationLatitude,
            "destinationLongitude": destinationLongitude,
            "riderLatitude":        riderLatitude,
            "riderLongitude":       riderLongitude,
            "status":               status.rawValue,
            "updatedAt":            Date(),
        ]
        if let eta  = estimatedArrival { data["estimatedArrival"] = eta }
        if let name = riderName        { data["riderName"]        = name }
        if let ph   = riderPhone       { data["riderPhone"]       = ph   }
        return data
    }

    /// Initialises a session from a Firestore snapshot dictionary.
    /// Returns nil when required fields are missing.
    init?(firestoreData d: [String: Any]) {
        guard
            let orderId              = d["orderId"]              as? String,
            let branchId             = d["branchId"]             as? String,
            let branchLat            = d["branchLatitude"]        as? Double,
            let branchLng            = d["branchLongitude"]       as? Double,
            let destLat              = d["destinationLatitude"]   as? Double,
            let destLng              = d["destinationLongitude"]  as? Double,
            let riderLat             = d["riderLatitude"]         as? Double,
            let riderLng             = d["riderLongitude"]        as? Double,
            let statusRaw            = d["status"]                as? String,
            let status               = DeliveryStatus(rawValue: statusRaw)
        else { return nil }

        self.orderId              = orderId
        self.branchId             = branchId
        self.branchLatitude       = branchLat
        self.branchLongitude      = branchLng
        self.destinationLatitude  = destLat
        self.destinationLongitude = destLng
        self.riderLatitude        = riderLat
        self.riderLongitude       = riderLng
        self.status               = status
        self.riderName            = d["riderName"]  as? String
        self.riderPhone           = d["riderPhone"] as? String

        if let ts = d["estimatedArrival"] as? Date {
            self.estimatedArrival = ts
        } else {
            self.estimatedArrival = nil
        }
    }

    /// Convenience init used when the simulator creates a fresh session.
    init(
        orderId:              String,
        branchId:             String,
        branchCoordinate:     CLLocationCoordinate2D,
        destinationCoordinate: CLLocationCoordinate2D,
        riderName:            String?  = "Dara",
        riderPhone:           String?  = "+855 12 345 678"
    ) {
        self.orderId              = orderId
        self.branchId             = branchId
        self.branchLatitude       = branchCoordinate.latitude
        self.branchLongitude      = branchCoordinate.longitude
        self.destinationLatitude  = destinationCoordinate.latitude
        self.destinationLongitude = destinationCoordinate.longitude
        // Rider starts at the branch
        self.riderLatitude        = branchCoordinate.latitude
        self.riderLongitude       = branchCoordinate.longitude
        self.status               = .orderPlaced
        self.estimatedArrival     = nil
        self.riderName            = riderName
        self.riderPhone           = riderPhone
    }
}
