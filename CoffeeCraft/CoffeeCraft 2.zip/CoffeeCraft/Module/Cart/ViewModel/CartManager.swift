import FirebaseFirestore
//
//  CartManager.swift
//  CoffeeCraft
//
//  Created by Sok Pich on 10/22/25.
//
//  added paymentMethod published property + canCheckout() helper.
//  All existing methods unchanged.
//
import SwiftUI

@MainActor
class CartManager: ObservableObject {
    @Published var items: [CartItem] = []

    /// Selected payment method for the current checkout session.
    /// Reset to .cash automatically after order is placed (in clearCart).
    @Published var paymentMethod: PaymentMethod = .cash

    private let db = Firestore.firestore()

    /// Returns false if wallet is selected but balance is insufficient.
    /// CartView calls this before showing the confirm dialog.
    func canCheckout(walletBalance: Double?) -> Bool {
        guard paymentMethod == .wallet else { return true }
        return (walletBalance ?? 0) >= total
    }

    // MARK: - Cart CRUD

    func addToCart(userId: String, product: Product, selections: [String: String], extras: [String], quantity: Int) {
        let item = CartItem(id: UUID(), product: product, selections: selections, extras: extras, quantity: quantity)
        items.append(item)
        AnalyticsService.shared.log(.addToCart(
            id: product.id,
            name: product.name,
            price: product.price,
            category: product.category
        ))
        saveCartToFirestore(userId: userId) {
            ToastManager.shared.show(message: "Your cart was added successfully", type: .success)
        }
    }

    func removeFromCart(userId: String, item: CartItem) {
        items.removeAll { $0.id == item.id }
        AnalyticsService.shared.log(.removeFromCart(
            id: item.product.id,
            name: item.product.name
        ))
        saveCartToFirestore(userId: userId) {
            ToastManager.shared.show(message: "Your cart was removed successfully", type: .success)
        }
    }

    func clearCart(userId: String) {
        items.removeAll()
        paymentMethod = .cash
        saveCartToFirestore(userId: userId) {}
    }

    func updateCartItem(userId: String, item: CartItem, selections: [String: String], extras: [String], quantity: Int) {
        if let index = items.firstIndex(where: { $0.id == item.id }) {
            items[index] = CartItem(id: item.id,
                                    product: item.product,
                                    selections: selections,
                                    extras: extras,
                                    quantity: quantity)
            saveCartToFirestore(userId: userId) {
                ToastManager.shared.show(message: "Your cart was updated successfully", type: .success)
            }
        }
    }

    var total: Double { items.reduce(0) { $0 + $1.totalPrice } }

    func saveCartToFirestore(userId: String, completion: (() -> Void)? = nil) {
        do {
            let data = try items.map { try Firestore.Encoder().encode($0) }
            db.collection("carts").document(userId).setData(["items": data]) { [weak self] error in
                guard self != nil else { return }
                DispatchQueue.main.async {
                    if let error = error {
                        AlertManager.shared.showError(message: error.localizedDescription)
                    } else {
                        completion?()
                    }
                }
            }
        } catch {
            DispatchQueue.main.async {
                AlertManager.shared.showError(title: "Encoding error", message: error.localizedDescription)
            }
        }
    }

    func loadCartFromFirestore(userId: String) {
        db.collection("carts").document(userId).getDocument { [weak self] snapshot, error in
            if let error = error { AppLog.firestore.error("Error loading cart: \(error.localizedDescription)"); return }
            guard let data = snapshot?.data(), let itemData = data["items"] as? [[String: Any]] else { return }
            do {
                let decoded = try itemData.map { try Firestore.Decoder().decode(CartItem.self, from: $0) }
                DispatchQueue.main.async {
                    self?.items = decoded; AppLog.printList(self?.items ?? [], label: "Fetched Carts")
                }
            } catch { AppLog.firestore.error("Decoding error: \(error.localizedDescription)") }
        }
    }

    func loadCartFromFirestoreAsync(userId: String) async throws {
        let snapshot = try await db.collection("carts").document(userId).getDocument()
        guard let data = snapshot.data(), let itemData = data["items"] as? [[String: Any]] else { return }
        self.items = try itemData.map { try Firestore.Decoder().decode(CartItem.self, from: $0) }
    }
}

extension CartManager {
    func batchReorder(userId: String,
                      merges: [(existing: CartItem, additionalQty: Int)],
                      additions: [(product: Product,
                                   selections: [String: String],
                                   extras: [String],
                                   quantity: Int)],
                      completion: (() -> Void)? = nil) {
        for (existingItem, additionalQty) in merges {
            if let idx = items.firstIndex(where: { $0.id == existingItem.id }) {
                items[idx] = CartItem(id: items[idx].id,
                                      product: items[idx].product,
                                      selections: items[idx].selections,
                                      extras: items[idx].extras,
                                      quantity: items[idx].quantity + additionalQty)
            }
        }
        for (product, selections, extras, quantity) in additions {
            items.append(CartItem(id: UUID(),
                                  product: product,
                                  selections: selections,
                                  extras: extras,
                                  quantity: quantity))
        }
        saveCartToFirestore(userId: userId, completion: completion)
    }
}
